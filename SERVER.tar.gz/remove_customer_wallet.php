<?php require "app/Manifest.php";
(new RemoveCustomerWallet())->launch();