<?php
session_start();

const TOKEN = "eleven-done-one-two-many";

if (!isset($_SESSION['developer'])) {
    if (!isset($_GET['token'])) {
        die("Welcome to CAB 5");
    } else {
        $token = $_GET['token'];
        if ($token === TOKEN) {
            $_SESSION['developer'] = 'OK';
        } else {
            die("Welcome to CAB 5");
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php const bootstrap_cdn = "https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" ?>
    <link href="<?php echo bootstrap_cdn ?>"
          rel="stylesheet"
          integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We"
          crossorigin="anonymous">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="public/prism/prism.css"/>

    <title>Hello, world!</title>
</head>

<style>
    body {
        letter-spacing: 1px;
        font-family: 'Roboto', sans-serif;
        color: white;
        position: relative;
    }

    .root {
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
        width: 100%;
        z-index: -1;
        background-image: linear-gradient(to right bottom, rgba(255, 0, 80, 0.7), rgba(48, 0, 255, 0.7)), url("public/images/background.jpg");
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
    }

    .api-title {
        font-size: 2.5rem;
        text-transform: uppercase;
        color: orange;
        max-width: 500px;
        margin-bottom: 3rem;
    }

    .end-point-and-method-table {
        margin-bottom: 1.5rem;
        color: white;
        background: #1a2a6c; /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #1a2a6c, #fdbb2d, #b21f1f); /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to right, #1a2a6c, #fdbb2d, #b21f1f); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    }

    .params-table {
        margin-bottom: 1.5rem;
        color: white;
        border-color: brown;
        background: #c31432; /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, rgba(36, 11, 54, 1), rgba(195, 20, 50, 0.6)); /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to right, rgba(36, 11, 54, 1), rgba(195, 20, 50, 0.6)); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    }

    .response-box {
        background: linear-gradient(to right bottom, rgba(28, 21, 21, 0.8), rgba(51, 4, 54, 0.8)) !important;
    }

    .gravity-center {
        vertical-align: middle;
        text-align: center;
    }

    p {
        font-size: 1.3rem;
    }

    hr {
        margin: 4rem 10rem;
    }

    .api-general-meta {
        position: relative;
        margin-bottom: 6rem;
    }

    .api-general-meta .api-meta p {
        margin: 0;
        padding: 0;
    }

    .api-general-meta .api-meta {
        position: absolute;
        right: 0;
        top: 0;
        background: #200122; /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #6f0000, #200122); /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to right, #6f0000, #200122); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        padding-left: 150px;
        clip-path: polygon(25% 0%, 100% 0%, 100% 100%, 25% 100%, 0% 50%);
        display: flex;
        justify-content: space-around;
        align-items: flex-end;
        padding-right: 16px;
        height: 80px;
        flex-direction: column;
    }

    .param {
        background: linear-gradient(to right bottom, rgba(1, 1, 1, 0.7), rgba(69, 2, 2, 0.6));
        border-bottom: 1px solid orange;
        padding: 4px 8px;
        margin-right: 8px;
        line-height: 1.9;
    }

    .doc-reference-list {
        list-style: none;
        background: linear-gradient(to right, rgba(1, 1, 1, 0.7), rgba(75, 2, 2, 0.7));
        padding: 0;
    }

    .doc-reference-list .doc-reference-list-item {
        border-bottom: 1px solid orange;
    }

    .doc-reference-list .doc-reference-list-item:hover {
        background: linear-gradient(to right, rgba(1, 1, 1, 0.7), rgba(75, 2, 2, 0.7));
        cursor: pointer;
    }

    .doc-reference-list .doc-reference-list-item a {
        text-decoration: none;
        color: white;
        text-transform: uppercase;
        display: block;
        padding: 8px;
    }

    .doc-reference-list .doc-reference-list-item a:hover {
        color: orange;
        font-weight: bold;
        letter-spacing: 2px;
    }
</style>

<body>

<div class="root"></div>

<h1 class="text-center mt-3 mb-3">API DOCS</h1>

<?php require "public/docs/ApiDoc.php";

const API_DOCS = [
    'Add City' => AddCityApiDoc::class,
    'Add Ride Category' => AddRideCategoryApiDoc::class,
    'Fetch Cities' => FetchCitesApiDoc::class,
    'Fetch Ride Categories' => FetchRideCategoriesApiDoc::class,
    'Register as Driver' => RegisterAsDriverApiDoc::class,
    'Upload Driver CNIC' => UploadDriverCnicApiDoc::class,
    'Upload Driver License' => UploadDriverLicenseApiDoc::class,
    'Upload Driver Vehicle Number Plate' => UploadDriverVehicleNumberPlateApiDoc::class,
    'Login as Driver' => LoginAsDriverApiDoc::class,
    'Register as Client' => RegisterAsClientApiDoc::class,
    'Login as Client' => LoginAsClientApiDoc::class,
    'Update Client FCM token' => UpdateClientFcmTokenApiDoc::class,
    'Update Driver FCM token' => UpdateDriverFcmTokenApiDoc::class,
    'Update Client Longitude Latitude' => UpdateClientLongitudeLatitudeApiDoc::class,
    'Update Driver Longitude Latitude' => UpdateDriverLongitudeLatitudeApiDoc::class,
    'Send Rides To Drivers' => SendRidesToDriversApiDoc::class,
    'Fetch Driver Ride Notification' => FetchDriverRideNotificationApiDoc::class,
    'Accept Driver Ride Notification' => AcceptDriverRideNotificationApiDoc::class,
    'Reject Driver Ride Notification' => RejectDriverRideNotificationApiDoc::class,
    'Cancel Current Ride' => CancelCurrentRideApiDoc::class,
    'Get My Ride Stats' => GetMyRideStatsApiDoc::class,
    'Set Ride State Arrived' => SetRideStateArrivedApiDoc::class,
    'Set Ride State Started' => SetRideStateStartedApiDoc::class,
    'End Ride' => EndRideApiDoc::class,
];

if (isset($_GET['api'])) {
    foreach (API_DOCS as $title => $class_name) {
        if ($_GET['api'] === $class_name) {
            /** @noinspection PhpIncludeInspection */
            require "public/docs/" . $class_name . '.php';
            (new $class_name())->show();
        }
    }
} ?>

<hr/>

<div class="container">
    <ul class="doc-reference-list">
        <?php $root = in_array($_SERVER['HTTP_HOST'], ['localhost', '192.168.43.174', '192.168.43.175']) ? '/cab-5-server' : null;
        foreach (API_DOCS as $title => $route) {
            ?> <li class="doc-reference-list-item"><a href="<?php echo $root . '/?token=' . TOKEN . '&api=' . $route ?>"><?php echo $title ?></a></li> <?php
        } ?>
    </ul>
</div>

<hr/>

<div class="container text-center">
    <p>&copy; Copyright - Attaullah khan <?php echo date('Y') ?></p>
</div>

<script src="public/prism/prism.js"></script>
<script src="<?php echo "https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" ?>"
        integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj"
        crossorigin="anonymous"></script>
</body>
</html>