<?php require "app/Manifest.php";
(new AddSendHistory())->launch();