<?php require "app/Manifest.php";
(new GetNotificationsWithCustomerId())->launch();