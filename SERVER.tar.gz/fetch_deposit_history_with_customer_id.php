<?php require "app/Manifest.php";
(new FetchDepositHistoryWithCustomerId())->launch();