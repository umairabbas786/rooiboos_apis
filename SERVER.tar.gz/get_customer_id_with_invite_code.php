<?php require "app/Manifest.php";
(new GetCustomerIdWithInviteCode())->launch();