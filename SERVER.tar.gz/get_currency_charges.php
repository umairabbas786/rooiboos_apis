<?php require "app/Manifest.php";
(new GetCurrencyCharges())->launch();