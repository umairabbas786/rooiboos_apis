<?php require "app/Manifest.php";
(new AddCustomerProfilePicture())->launch();