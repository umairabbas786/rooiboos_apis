<?php require "app/Manifest.php";
(new AddDepositHistory())->launch();