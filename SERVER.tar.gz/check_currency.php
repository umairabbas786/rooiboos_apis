<?php require "app/Manifest.php";
(new CheckCurrency())->launch();