<?php require "app/Manifest.php";
(new CreateCustomerWallet())->launch();