<?php require "app/Manifest.php";
(new GetDepositFee())->launch();