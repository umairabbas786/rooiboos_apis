<?php require "app/Manifest.php";
(new FetchCountries())->launch();