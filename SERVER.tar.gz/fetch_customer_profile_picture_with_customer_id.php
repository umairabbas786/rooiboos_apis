<?php require "app/Manifest.php";
(new FetchCustomerProfilePictureWithCustomerId())->launch();