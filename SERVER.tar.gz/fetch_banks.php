<?php require "app/Manifest.php";
(new FetchBanks())->launch();