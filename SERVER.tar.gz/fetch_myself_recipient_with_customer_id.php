<?php require "app/Manifest.php";
(new FetchMyselfRecipientWithCustomerId())->launch();