<?php require "app/Manifest.php";
(new FetchSomeoneRecipientWithCustomerId())->launch();