<?php require "app/Manifest.php";
(new AddSomeoneRecipient())->launch();