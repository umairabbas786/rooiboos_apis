<?php require "app/Manifest.php";
(new AddWithdrawHistory())->launch();