<?php require "app/Manifest.php";
(new GenerateInviteCode())->launch();