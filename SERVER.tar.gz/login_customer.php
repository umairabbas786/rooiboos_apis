<?php require "app/Manifest.php";
(new LoginCustomer())->launch();