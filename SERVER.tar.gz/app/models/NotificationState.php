<?php

class NotificationState {
    const READ = "READ";
    const UNREAD = "UNREAD";
}