<?php require "app/Manifest.php";
(new FetchCustomerWithEmail())->launch();