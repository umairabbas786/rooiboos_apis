<?php require "app/Manifest.php";
(new RegisterCustomer())->launch();