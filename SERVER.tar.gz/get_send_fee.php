<?php require "app/Manifest.php";
(new GetSendFee())->launch();