<?php require "app/Manifest.php";
(new GetCurrencyFee())->launch();