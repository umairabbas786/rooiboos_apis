<?php require "app/Manifest.php";
(new EditCustomerDetails())->launch();