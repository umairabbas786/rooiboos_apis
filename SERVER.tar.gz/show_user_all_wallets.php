<?php require "app/Manifest.php";
(new ShowUserAllWallets())->launch();