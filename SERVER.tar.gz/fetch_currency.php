<?php require "app/Manifest.php";
(new FetchCurrency())->launch();