<?php require "app/Manifest.php";
(new UpdateNotificationsAsRead())->launch();