<?php require "app/Manifest.php";
(new WithdrawBalance())->launch();