<?php require "app/Manifest.php";
(new CheckTransactionWithCustomerId())->launch();