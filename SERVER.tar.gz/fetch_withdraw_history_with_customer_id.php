<?php require "app/Manifest.php";
(new FetchWithdrawHistoryWithCustomerId())->launch();