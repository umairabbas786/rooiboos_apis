<?php require "app/Manifest.php";
(new AddMyselfRecipient())->launch();