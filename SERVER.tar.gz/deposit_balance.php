<?php require "app/Manifest.php";
(new DepositBalance())->launch();