<?php require "app/Manifest.php";
(new UpdateCustomerProfilePicture())->launch();