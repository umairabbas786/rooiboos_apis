<?php require "app/Manifest.php";
(new GetInviteCodeWithCustomerId())->launch();