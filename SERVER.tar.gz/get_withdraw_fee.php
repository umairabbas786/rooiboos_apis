<?php require "app/Manifest.php";
(new GetWithdrawFee())->launch();