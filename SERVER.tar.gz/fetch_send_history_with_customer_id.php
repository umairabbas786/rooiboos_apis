<?php require "app/Manifest.php";
(new FetchSendHistoryWithCustomerId())->launch();